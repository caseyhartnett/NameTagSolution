# NameTags batch

Fictional sample data; not a roster of real people.

12 labels on 2 arranged model 3MF plates.
Open numbered 3MF files separately. Each label is one assembly with white body
and black face; preserve alignment and all black islands. Verify actual filament
assignments. No printer profile, G-code, purge tower or brim space is included.
6 mm bed margins and 3 mm gaps were checked; packing is a heuristic.

Print face-down, 0.4 mm nozzle, 0.2 mm layers, PLA, supports off. Both colors
share the first layers. No height-only color swap. `all_labels.png` shows fronts;
plate PNGs show mirrored bed views. Exact mesh edges/winding, complementary
volumes, containment and all 3MF mesh coordinates were checked. lib3mf parsed
each file without warnings. No physical or sliced-toolpath trial is claimed.

`presets.json` records all input. `source/` is an independent build snapshot.
From its root: `python tools/nametags.py build --presets presets.json --out build/rebuild`
